﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //新增檢驗
        protected void Button1_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            conn.Open();
            SqlCommand cmd2 = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT test FROM [Test] WHERE test=@test", conn);
                cmd.Parameters.Add("@test", SqlDbType.NVarChar,50).Value = TextBox1.Text;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    Label1.Text = "檢驗已存在!";
                }
                else
                {
                    cmd.Cancel();
                    reader.Close();
                    cmd2 = new SqlCommand("Insert [Test] (test) Values(@test)", conn);
                    cmd2.Parameters.Add("@test", SqlDbType.NVarChar, 50).Value = TextBox1.Text;
                    cmd2.ExecuteNonQuery();
                    Label1.Text = "新增檢驗成功!";
                    //show();
                    cmd2.Cancel();
                }
                cmd.Cancel();
            }
            catch (Exception ex)
            {
                Label1.Text += ex.ToString();
            }

            
            conn.Close();
            conn.Dispose();
        }

        //清空
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
        }

        //跳回首頁
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx?");
        }
    }
}