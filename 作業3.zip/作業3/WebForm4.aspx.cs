﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connString);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [檢驗結果]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "[檢驗結果]");

            conn.Close();
            conn.Dispose();

            GridView1.DataSource = ds;
            GridView1.DataBind();

            if(!IsPostBack)
            {
                SqlConnection conn1 = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
                SqlDataAdapter da2 = new SqlDataAdapter("SELECT * FROM [Test]", conn1);
                DataSet ds2 = new DataSet();
                da2.Fill(ds2, "[Test]");
                DataTable mytable = ds2.Tables["[Test]"];
                RadioButtonList1.DataSource = mytable;
                RadioButtonList1.DataTextField = mytable.Columns["test"].ToString();
                RadioButtonList1.DataValueField = mytable.Columns["test"].ToString();
                RadioButtonList1.DataBind();

                SqlDataAdapter da3 = new SqlDataAdapter("SELECT * FROM [Doctor]", conn1);
                DataSet ds3 = new DataSet();
                da3.Fill(ds3, "[Doctor]");
                DataTable mytable2 = ds3.Tables["[Doctor]"];
                DropDownList1.DataSource = mytable2;
                DropDownList1.DataTextField = mytable2.Columns["doctor_ID"].ToString();
                DropDownList1.DataValueField = mytable2.Columns["doctor_ID"].ToString();
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [檢驗結果]", conn);
            SqlCommandBuilder cmbd = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds, "[檢驗結果]");
            DataTable table = ds.Tables["[檢驗結果]"];
            DataRow[] dataRow = table.Select("patient_ID='" + Label2.Text + "'");
            table.Rows[table.Rows.IndexOf(dataRow[0])].Delete();
            DataRow row = table.NewRow();
            row["patient_ID"] = Label2.Text;
            row["patient_Name"] = Label3.Text;
            row["doctor_ID"] = DropDownList1.SelectedValue;
            row["doctor_name"] = TextBox6.Text;
            row["patient_day"] = TextBox5.Text;
            row["patient_num"] = RadioButtonList1.SelectedValue;
            row["result"] = DropDownList2.SelectedValue;
            table.Rows.Add(row);
            da.Update(table);
            DataView view = new DataView(table, "patient_ID='" + Label2.Text + "'","patient_ID" ,DataViewRowState.CurrentRows);
            if(view.Count>0)
            {
                GridView1.DataSource = view;
                GridView1.DataBind();
                Response.Write("<script type='text/javascript'>alert('資料更新成功')</script>");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('資料更新失敗')</script>");
            }
        }
        
        //清空
        protected void Button2_Click(object sender, EventArgs e)
        {
            //TextBox1.Text = "";

            //TextBox3.Text = "";
            //TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            DropDownList1.ClearSelection();
            DropDownList2.ClearSelection();
            RadioButtonList1.ClearSelection();
        }
        
        //跳回首頁
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx?");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [Doctor]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Doctor]");
            DataTable table = ds.Tables["[Doctor]"];
            DataRow[] row = table.Select("doctor_ID=" + DropDownList1.SelectedValue);
            TextBox6.Text = row[0]["doctor_Name"].ToString();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName=="編輯")
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
                Panel1.Visible = true;
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow selectedRow = GridView1.Rows[index];
                string name = selectedRow.Cells[1].Text;
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [檢驗結果]", conn);
                DataSet ds = new DataSet();
                da.Fill(ds, "[檢驗結果]");
                DataTable table = ds.Tables["[檢驗結果]"];
                DataRow[] dataRow = table.Select("patient_ID='" + name + "'");
                Label2.Text = dataRow[0]["patient_ID"].ToString();
                Label3.Text = dataRow[0]["patient_Name"].ToString();
                TextBox5.Text = dataRow[0]["patient_day"].ToString();
            }
           
        }
    }
}