﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //判斷日期
            //DateTime strDate = DateTime.Parse(TextBox3.Text);
            //if (strDate <= DateTime.Now.Date)
            //{
            //}
            //else
            //{
            //Label1.Text = "請輸入正確的出生年月日!";
            //}
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter("Select * FROM [檢驗結果]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "[檢驗結果]");
            DateTime Date = DateTime.Parse(TextBox1.Text);
            DataView view = new DataView(ds.Tables["[檢驗結果]"], "patient_day='"+Date+"'", "patient_day", DataViewRowState.CurrentRows);
            if (view.Count > 0)
            {
                GridView1.DataSource = view;
                GridView1.DataBind();
            }
            else
            {
                Label1.Text = "此日期無人檢驗";
            }

            //SqlDataReader dr = cmd.ExecuteReader();

        }
        //清空
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
        }
        //跳回首頁
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx?");
        }
        //分頁
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataBind();
        }
    }
}