﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connString);
            conn.Open();

            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [檢驗結果]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "[檢驗結果]");

            conn.Close();
            conn.Dispose();

            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if(e.CommandName=="選取")
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow selectedRow = GridView1.Rows[index];
                string name = selectedRow.Cells[1].Text;
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [檢驗結果]", conn);
                DataSet ds = new DataSet();
                da.Fill(ds, "[檢驗結果]");
                DataTable table = ds.Tables["[檢驗結果]"];
                DataView view = new DataView(table, "patient_ID='" + name + "'", "patient_ID", DataViewRowState.CurrentRows);
                if (view.Count > 0)
                {
                    DetailsView1.DataSource = view;
                    DetailsView1.DataBind();
                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('錯誤')</script>");
                }
            }
        }
    }
}