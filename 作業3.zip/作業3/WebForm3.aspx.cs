﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [Test]", conn);
                DataSet ds = new DataSet();
                da.Fill(ds, "[Test]");
                DataTable mytable = ds.Tables["[Test]"];
                RadioButtonList1.DataSource = mytable;
                RadioButtonList1.DataTextField = mytable.Columns["test"].ToString();
                RadioButtonList1.DataValueField = mytable.Columns["test"].ToString();
                RadioButtonList1.DataBind();

                SqlDataAdapter da2 = new SqlDataAdapter("SELECT * FROM [Doctor]", conn);
                DataSet ds2 = new DataSet();
                da2.Fill(ds2, "[Doctor]");
                DataTable mytable2 = ds2.Tables["[Doctor]"];
                DropDownList1.DataSource = mytable2;
                DropDownList1.DataTextField = mytable2.Columns["doctor_ID"].ToString();
                DropDownList1.DataValueField = mytable2.Columns["doctor_ID"].ToString();
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //判斷日期
            //DateTime strDate = DateTime.Parse(TextBox3.Text);
            //if (strDate <= DateTime.Now.Date)
            //{
            //}
            //else
            //{
            //Label1.Text = "請輸入正確的出生年月日!";
            //}
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            conn.Open();
            SqlCommand cmd2 = null;
            SqlCommand cmd3 = null;
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT patient_ID FROM [病患個資] WHERE patient_ID=@patient_ID", conn);
                cmd.Parameters.Add("@patient_ID", SqlDbType.NVarChar, 50).Value = TextBox2.Text;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    Label1.Text = "此身分證已存在!";
                }
                else
                {
                    cmd.Cancel();
                    reader.Close();
                    cmd2 = new SqlCommand("Insert Into [病患個資] ( patient_ID,patient_Name,patient_birth,patient_home) Values(@patient_ID,@patient_Name,@patient_birth,@patient_home) ", conn);
                    cmd2.Parameters.Add("@patient_ID", SqlDbType.NVarChar, 50).Value = TextBox2.Text;
                    cmd2.Parameters.Add("@patient_Name", SqlDbType.NVarChar, 50).Value = TextBox1.Text;
                    cmd2.Parameters.Add("@patient_birth", SqlDbType.Date).Value = TextBox3.Text;
                    cmd2.Parameters.Add("@patient_home", SqlDbType.NVarChar, 50).Value = TextBox4.Text;
                    cmd2.ExecuteNonQuery();
                    cmd2.Cancel();

                    cmd3 = new SqlCommand("Insert Into [檢驗結果] ( patient_ID,patient_Name,doctor_ID,doctor_name,patient_day,patient_num,result) Values(@patient_ID,@patient_Name,@doctor_ID,@doctor_name,@patient_day,@patient_num,@result) ", conn);
                    cmd3.Parameters.Add("@patient_ID", SqlDbType.NVarChar, 50).Value = TextBox2.Text;
                    cmd3.Parameters.Add("@patient_Name", SqlDbType.NVarChar, 50).Value = TextBox1.Text;
                    cmd3.Parameters.Add("@doctor_ID", SqlDbType.NVarChar, 50).Value = DropDownList1.SelectedValue;
                    cmd3.Parameters.Add("@doctor_name", SqlDbType.NVarChar, 50).Value = TextBox6.Text;
                    cmd3.Parameters.Add("@patient_day", SqlDbType.Date).Value = TextBox5.Text;
                    cmd3.Parameters.Add("@patient_num", SqlDbType.NVarChar, 50).Value = RadioButtonList1.SelectedValue;
                    cmd3.Parameters.Add("@result", SqlDbType.NVarChar,50).Value =DropDownList2.SelectedValue;
                    cmd3.ExecuteNonQuery();
                    Label1.Text = "新增資料成功!";
                    cmd3.Cancel();
                    ////show();
                }
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                Label1.Text = ex.ToString();
            }
            conn.Close();
            conn.Dispose();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            DropDownList1.ClearSelection();
            DropDownList2.ClearSelection();
            RadioButtonList1.ClearSelection();
        }

        //跳回首頁
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx?");
        }

        //醫師ID對應姓名
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [Doctor]", conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Doctor]");
            DataTable table = ds.Tables["[Doctor]"];
            DataRow[] row = table.Select("doctor_ID=" + DropDownList1.SelectedValue);
            TextBox6.Text = row[0]["doctor_Name"].ToString();
        }
    }
}