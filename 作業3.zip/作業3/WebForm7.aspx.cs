﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 作業3
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //登入驗證
        protected void Button1_Click(object sender, EventArgs e)
        {
            string[] users = { "123", "456", "789", "110316123" };
            string[] passward = { "123", "456", "789", "110316123" };
            for (int i = 0; i < 4; i++)
            {
                if (users[i] == TextBox1.Text && passward[i] == TextBox2.Text)
                {
                    Session["user"] = users[i];
                    Session["passward"] = passward[i];
                    Response.Redirect("WebForm1.aspx");
                }
                else
                    Label4.Visible = true;
            }
        }
    }
}