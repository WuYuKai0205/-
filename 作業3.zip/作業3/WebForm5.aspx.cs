﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace 作業3
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True");
            conn.Open();
            //SqlCommand cmd = new SqlCommand("Select * From 病人資料 Where  patient_ID=@patient_ID", conn);
            SqlDataAdapter da = new SqlDataAdapter("Select * FROM [檢驗結果]", conn);

            DataSet ds = new DataSet();
            da.Fill(ds, "[檢驗結果]");

            //DataTable mytable = ds.Tables["[檢驗結果]"];
            // DataRow[] rows = mytable.Select("patient_ID='" + TextBox1.Text + "'");
            DataView view = new DataView(ds.Tables["[檢驗結果]"], "patient_ID='" +TextBox1.Text+"'" , "patient_ID", DataViewRowState.CurrentRows);
            if (view.Count > 0)
            {
                GridView1.DataSource = view;
                GridView1.DataBind();
            }
            else
            {
                Label1.Text = "無此身分證";
            }

            //SqlDataReader dr = cmd.ExecuteReader();

        }
        //清空
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
        }
        //跳回首頁
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx?");
        }
    }
}